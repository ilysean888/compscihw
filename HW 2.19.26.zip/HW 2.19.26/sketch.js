
let circleSize = 50;
let circleColor = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(220);

  circleSize += 0.5;
  
  fill(circleColor, 100, 200);
  ellipse(mouseX, mouseY, circleSize, circleSize);
}

function mousePressed() {
  
  circleColor = random(255);
}